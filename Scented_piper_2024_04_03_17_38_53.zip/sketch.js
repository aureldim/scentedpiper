function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let hearts = []; // Array to store heart objects

function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  background(255); // White background

  // Create new hearts randomly
  if (random() < 0.05) { // Adjust this value to control the frequency of heart creation
    let x = random(width); // Random x position
    let y = random(height); // Random y position
    let size = random(30, 100); // Random size
    let color = getRandomColor(); // Random color
    let heart = new Heart(x, y, size, color);
    hearts.push(heart);
  }

  // Update and display all hearts
  for (let i = hearts.length - 1; i >= 0; i--) {
    hearts[i].update();
    hearts[i].display();
    // Remove hearts that have faded out
    if (hearts[i].alpha <= 0) {
      hearts.splice(i, 1);
    }
  }
}

// Heart class definition
class Heart {
  constructor(x, y, size, color) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.color = color;
    this.alpha = 255; // Initial opacity
    this.gravity = random(0.1, 0.3); // Random gravity
    this.xSpeed = random(-2, 2); // Random horizontal speed
    this.ySpeed = random(-5, -1); // Random vertical speed
  }

  update() {
    // Apply gravity
    this.ySpeed += this.gravity;
    // Update position
    this.x += this.xSpeed;
    this.y += this.ySpeed;
    // Fade out over time
    this.alpha -= 2;
  }

  display() {
    // Set color and opacity
    fill(this.color[0], this.color[1], this.color[2], this.alpha);
    // Draw heart
    beginShape();
    vertex(this.x, this.y - this.size / 2);
    bezierVertex(this.x - this.size / 2, this.y - this.size / 4,
                 this.x - this.size / 2, this.y + this.size / 3,
                 this.x, this.y + this.size / 2);
    bezierVertex(this.x + this.size / 2, this.y + this.size / 3,
                 this.x + this.size / 2, this.y - this.size / 4,
                 this.x, this.y - this.size / 2);
    endShape(CLOSE);
  }
}

// Function to generate a random color
function getRandomColor() {
  let r = random(255);
  let g = random(255);
  let b = random(255);
  return [r, g, b];
}
